Instructions:
In terminal, change directory to folder that contains server.js and client.js files.

Afterward, run these commands:
npm init -y
npm install

To setup server, type:
node server.js

Once this is done, you can go on a browser and type:
localhost:3000

Since this is the multiplayer version, you cannot play until another player joins which can easily be done by opening another tab and going to localhost:3000 again.




loading gif credit:
https://giphy.com/gifs/hamburglar-12zV7u6Bh0vHpu

Referenced: 
https://www.youtube.com/watch?v=4ARsthVnCTg&ab_channel=KennyYipCoding
https://github.com/ImKennyYip/Connect4
https://simulationcorner.net/index.php?page=connectfour 
https://www.youtube.com/watch?v=LpSvzaPsnVI
https://github.com/jahid28/RealTimeTicTacToe
