Referenced: 
https://www.youtube.com/watch?v=4ARsthVnCTg&ab_channel=KennyYipCoding
https://github.com/ImKennyYip/Connect4
https://simulationcorner.net/index.php?page=connectfour 